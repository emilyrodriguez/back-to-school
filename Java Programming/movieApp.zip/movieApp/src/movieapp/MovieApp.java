/*
 * Emily Rodriguez
 * 7/11/18
 * Program takes user input of desired category selection and outputs associated movies
 */
package movieapp;

import java.util.Scanner;
import java.util.ArrayList;

/**
 * The <code>MovieApp</code> class holds main program logic
*/
public class MovieApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String category;

        /**Gets and adds movie to list*/
        ArrayList<Movie> movieList = createMovieList();
        
        /**Display greeting and movie count*/
        System.out.println("The Movie List application");
        System.out.println("Choose from " + (movieList.size() - 1) + " movies.");
        
        /** Default to y so program runs when loaded */
        Scanner sc = new Scanner(System.in);
        String choice = "y";

        /**Keeps program looping until user ends it*/
        while (choice.equalsIgnoreCase("y")) {
        
        /**Creates and adds categories for user to select*/
        ArrayList<String> categoryList = createCategoryList();
            
            /**Prompts user for selection*/
            int genreChoice = Console.getInt(sc, "Enter category number: ");
            
            /**Takes category number and sets the desired category*/
            switch(genreChoice) {
                case 1:
                    category = "Animated";
                    break;
                case 2:
                    category = "Comedy";
                    break;
                case 3:
                    category = "Drama";
                    break;
                case 4:
                    category = "Horror";
                    break;
                case 5:
                    category = "Musical";
                    break;
                case 6:
                    category = "Scifi";
                    break;
                default:
                    category = "Error";
                    break;
            }
            
            /**Validates that genreChoice is a number between 1 and 6*/
            if(genreChoice <= 0 || genreChoice > 6) {
                System.out.println("Invalid selection. Please enter a number 1-6.");
            } else {                
                /**Create counter to count number of movies in genre*/
                int count = 0;
                
                /**Find movies that match category, update count as matching movies are found*/
                for(Movie movie : movieList) {
                    if (movie.category.equalsIgnoreCase(category)) {
                       System.out.println(movie.title);
                       count++;
                    }
                }
                /**Output number of movies in category*/
                System.out.println("Total " + category + " movies: " + count);
            }
            /**Asks user if they want to continue to use the program*/
           choice = Console.getStringContinue(sc, "Continue? (y/n): "); 
        }
        System.out.println("Bye!");
    }

    /**
     * Gets the movie list from MovieIO and creates and adds movies to new Array List
     * @return An <code>ArrayList</code> of all the movies contained in MovieIO
     */
    public static ArrayList<Movie> createMovieList() {
        Movie m;
        ArrayList<Movie> creatingMovieList = new ArrayList<>();
        
        for (int i = 0; i <= 100; i++ ) {
            m = MovieIO.getMovie(i);
            creatingMovieList.add(m);
        }
        return creatingMovieList;
    }
    
    /**
     * Create Array list of genres and add genres to the list
     * @return An <code>ArrayList</code> of all categories for user to choose from
     */
    public static ArrayList<String> createCategoryList() {        
            ArrayList<String> categoryList = new ArrayList<>(6);
            categoryList.add("1. Animated");
            categoryList.add("2. Comedy");
            categoryList.add("3. Drama");
            categoryList.add("4. Horror");
            categoryList.add("5. Musical");
            categoryList.add("6. Sci-fi");
            
            /**Print genre selections to console*/
            for(String categorySelection : categoryList) {
                System.out.println(categorySelection);
            }
            
            return categoryList;
    }
}
