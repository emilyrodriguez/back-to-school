package movieapp;

import java.util.Scanner;

/**
 * The <code>Console</code> class validates user input from MovieApp
*/
public class Console {
    
    /**
     * Validates user choice to continue program use
     * @param sc A <code>Scanner</code> that gets user input
     * @param prompt A <code>String</code> contains user direction
     * @return s A <code>String</code> that contains user character input
     */
    public static String getStringContinue(Scanner sc, String prompt) {
        boolean isValid = false;
        String s = "";
        while (isValid == false) {
            System.out.print(prompt);
            if (sc.hasNext("y")) {
                s = sc.nextLine();
                isValid = true;
            } else if (sc.hasNext("n")) {
                s = sc.nextLine();
                isValid = true;
            } else {
                s = sc.nextLine();
                isValid = false;
                System.out.println("Error! Entry must be 'y' or 'n'. Try again.");
            }
        }
        return s;
    }
    
    /**
     * Validates user's input to check if it is an int
     * @param sc A <code>Scanner</code> that gets user input
     * @param prompt A <code>String</code> contains user direction
     * @return i An<code>Int</code> that contains user number input
     */
    public static int getInt(Scanner sc, String prompt) {
        int i = 0;
        boolean isValid = false;
        while (isValid == false) {
            System.out.print(prompt);
            if (sc.hasNextInt()) {
                i = sc.nextInt();
                isValid = true;
            } else {
                System.out.println("Error! Entry was not a number.");
            }
            sc.nextLine();
        }
        return i;
    }

}
