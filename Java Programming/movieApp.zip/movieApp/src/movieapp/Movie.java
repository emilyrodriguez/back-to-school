package movieapp;

/**
 * The <code>Movie</code> class sets/gets each movie's title and category
*/
public class Movie {
    public String title;
    public String category;
    
    /**
     * Sets title and category for movie object by calling setTitle() and
     * setCategory()
     * @param title  A <code>String</code> that holds the movie's title
     * @param category A <code>String</code> that holds the movie's category
    */
    public Movie(String title, String category) {
        setTitle(title);
        setCategory(category);
    }
    
    /**
     * Gets the movie's title
     * @return title  A <code>String</code> containing the movie's title
    */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the movie's title
     * @param title  A <code>String</code> containing the movie's title
    */
    public void setTitle(String title) {
        this.title = title;
    }
    
    /**
     * Gets the movie's category
     * @return category  A <code>String</code> containing the movie's category
    */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the movie's category
     * @param category  A <code>String</code> containing the movie's category
    */
    public void setCategory(String category) {
        this.category = category;
    }
}
