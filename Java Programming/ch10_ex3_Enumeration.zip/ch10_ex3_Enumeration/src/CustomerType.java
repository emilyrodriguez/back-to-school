/**
 *
 * @author Emily Rodriguez
 * Creating enumeration to hold the three types of customers and display which 
 * type they are
 */
public enum CustomerType {
    //constants for the 3 types of customers
    RETAIL,
    TRADE,
    COLLEGE;
    
    //overrides toString() to return customer type
    @Override
    public String toString() {
        String s = "";
        if(this.ordinal() == 0) {
            s = "Retail Customer";
        } else if(this.ordinal() == 1) {
            s = "Trade Customer";
        } else if(this.ordinal() == 2) {
            s = "College Customer";
        }
        return s;
    }
    
}
