/**
 * 
 * @author Emily Rodriguez
 * 6/25/18
 * Program takes CustomerType and displays what type of customer is assigned 
 * (college, retail, trade) and their associated discount using enumeration
 */
public class CustomerTypeApp {

    public static void main(String[] args) {
        // display a welcome message
        System.out.println("Welcome to the Customer Type Test application\n");

        // get and display the discount percent for a customer type
        CustomerType college = CustomerType.COLLEGE;
        double discountPercentage = getDiscountPercentage(college);
        System.out.println("Discount " + discountPercentage + "%\n");
        
        // display the value of the toString method of a customer type
        System.out.println(college.toString() + "\n");
    }

    // a method that accepts a CustomerType enumeration
    public static double getDiscountPercentage(CustomerType ct) {
        double discountPercentage = 0;
        
        if (ct == CustomerType.RETAIL) {
            discountPercentage = .10;
        } else if(ct == CustomerType.TRADE) {
            discountPercentage = .30;
        } else if(ct == CustomerType.COLLEGE) {
            discountPercentage = .20;
        }
        
        return discountPercentage;
    }
}
