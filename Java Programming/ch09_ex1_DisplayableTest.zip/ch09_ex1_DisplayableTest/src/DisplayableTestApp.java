/*
    *Emily Rodriguez
    *6/19/18
    *This code uses interfaces to display an employee's name and department and product information
*/
public class DisplayableTestApp {

    public static void main(String args[]) {
        System.out.println("Welcome to the Displayable Test application\n");

        // create an Employee object and display it using Displayable type
        Displayable e = new Employee(2, "Smith", "John");
        display(e);

        // create a Product object and display it using Displayable type
        Displayable p = new Product("java", "Murach's Java Programming", 57.50);
        display(p);
        
        System.out.println();        
    }
    
    //uses Displayable interface's getDisplatText() default method to output data
    private static void display(Displayable d) {
        System.out.println(d.getDisplayText());
    }
}