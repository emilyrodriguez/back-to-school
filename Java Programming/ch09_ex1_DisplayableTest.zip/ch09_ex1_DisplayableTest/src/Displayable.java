//creating Displayable interface
public interface Displayable {
    //getDisplayText() is the default method used to return the string object returned by toString()
    default String getDisplayText() {
        return toString();
    }
}
