//creating Employee class to implement DepartmentConstants and Displayable interfaces
public class Employee implements DepartmentConstants, Displayable {
    //declaring variables/fields
    private int department;
    private String firstName;
    private String lastName;

    //setting the value of Employee varaibles/fields to equal one particular object instance
    public Employee(int department, String lastName, String firstName) {
        this.department = department;
        this.lastName = lastName;
        this.firstName = firstName;
    }

    //returns the Employee's name and department by overriding toString()
    @Override
    public String toString() {
        //create empty string to serve as output
        String text = "";
        //set value of string to equal employee's name
        text += firstName + " " + lastName;
        //creating empty string to hold employee's department
        String dept = "";
        //reads the department variable and determines which employee belongs to it
        if (department == ADMIN) {
            dept = "Administration";
        } else if (department == EDITORIAL) {
            dept = "Editorial";
        } else if (department == MARKETING) {
            dept = "Marketing";
        }
        //concatinates employee name and department strings
        text += " (" + dept + ")";
        //returns new text String variable/field
        return text;
    }
}