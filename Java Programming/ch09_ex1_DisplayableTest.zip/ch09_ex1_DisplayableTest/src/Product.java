import java.text.NumberFormat;

//Creating Product class and make it implement the Displayable interface.
public class Product implements Displayable {

    //declaring variables/fields
    private String code;
    private String description;
    private double price;

    //assigning the value of variables/fields to empty string or zero
    public Product() {
        this.code = "";
        this.description = "";
        this.price = 0;
    }

    //setting the value of varaibles/fields to equal one particular object instance
    public Product(String code, String description, double price) {
        this.code = code;
        this.description = description;
        this.price = price;
    }

    //setting the value of the code variable/field
    public void setCode(String code) {
        this.code = code;
    }
    //getting the value of the code variable/field
    public String getCode() {
        return code;
    }
    //setting the value of the description variable/field
    public void setDescription(String description) {
        this.description = description;
    }
    //getting the value of the description variable/field
    public String getDescription() {
        return description;
    }
    //setting the value of the price variable/field
    public void setPrice(double price) {
        this.price = price;
    }
    //setting the value of the price variable/field
    public double getPrice() {
        return price;
    }

    //Formatting the output of price to match standard format $x.xx
    public String getPriceFormatted() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(price);
    }

    //returns a description of the product by overriding toString()
    @Override
    public String toString() {
        return getDescription();
    }
}