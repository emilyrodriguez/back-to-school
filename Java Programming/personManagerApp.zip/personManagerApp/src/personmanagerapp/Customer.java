package personmanagerapp;

public class Customer extends Person {
    //declare variable for customer number
    private String number;
    
    //call superclass, set arguments to get first and last values, set number to blank
    public Customer(String first, String last, String number) {
        super(first, last);
        this.number = number;
    }
    
    //get value for number variable/field
    public String getCustomerNumber() {
        return number;
    }
    
    //set value for number variable/field
    public void setCustomerNumber(String number) {
        this.number = number;
    }
    
    //override toString() to get Customer information in correct format
    @Override
    public String toString() {
        return "You entered a new customer:\n" + super.toString() + "\nCustomer Number: " +  this.number;
    }
}
