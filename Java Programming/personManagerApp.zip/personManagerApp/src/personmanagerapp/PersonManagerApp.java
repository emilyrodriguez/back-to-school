/*
 * Emily Rodriguez
 * 6/17/18
 * Program creates and stores employee and/or customer information and validates user input.
 */
package personmanagerapp;
import java.util.Scanner;

public class PersonManagerApp {

    public static void main(String[] args) {
        // display a welcome message
        System.out.println("Welcome to the Person Manager");
        System.out.println();
        
        //Default to y so program runs when loaded
        Scanner sc = new Scanner(System.in);
//        Person person = new Person();
        String choice = "y";
        
        //While the user input's "y" to keep the program going
        while (choice.equalsIgnoreCase("y")) {
//            System.out.print("Create customer or employee (c/e): ");
            String userType = Console.getStringCreate(sc, "Create customer or employee (c/e): ");
            
            //Input "c" to enter Customer Manager portion of program
            if(userType.equalsIgnoreCase("c")) {
                
                //Enter and store customer's first name, run through Console class method getStringInput for validation
                String first = Console.getStringInput(sc, "Enter customer's first name: ");
                //Enter and store customer's last name, run through Console class method getStringInput for validation
                String last = Console.getStringInput(sc, "Enter customer's last name: ");
                //Enter and store customer number, run through Console class method getStringInput for validation
                String number = Console.getStringInput(sc, "Enter customer number: ");

                // Create new customer
                Customer c = new Customer(first, last, number);
              
                
                //Output new customer information
                System.out.println();
                // Print new Customer info
                System.out.println(c.toString());
            } else if (userType.equalsIgnoreCase("e")) {
                //Input "e" to enter Employee Manager portion of program
                //Enter and store employee's first name, run through Console class method getStringInput for validation
                String first = Console.getStringInput(sc, "Enter employee's first name: ");
                //Enter and store employee's last name, run through Console class method getStringInput for validation
                String last = Console.getStringInput(sc, "Enter employee's last name: ");
                //Enter and store employee's last 4 of SSN, run through Console class method getStringInput for validation
                String SSN = Console.getStringInput(sc, "Enter employee's last 4 digits of SSN: ");
                
                //Create new Employee 
                Employee e = new Employee(first, last, SSN);
                //Output new Employee Information
                System.out.println( e.toString());
            }
            // see if the user wants to continue
            choice = Console.getStringContinue(sc, "Continue? (y/n): ");
        }
    }    
}
