package personmanagerapp;
import java.util.Scanner;

public class Console {
    public static String getStringContinue(Scanner sc, String prompt) {
        //set validation to default to false
        boolean isValid = false;
        //create empty string to take in input information
        String s = "";
        //while input is invalid
        while (isValid == false) {
            System.out.print(prompt);
            if (sc.hasNext("y")) {
                // read line, if input matches "y", isValid is now true
                s = sc.nextLine();
                isValid = true;
            } else if (sc.hasNext("n")) {
                //read line, if input matches "n", isValid is now true
                s = sc.nextLine();
                isValid = true;
            } else {
                // read line, if input is not "y" or "n" display error message
                s = sc.nextLine();
                isValid = false;
                System.out.println("Error! Entry must be 'y' or 'n'. Try again.");
            }
        }
        //return the value of s
        return s;
    }
    
    public static String getStringCreate(Scanner sc, String prompt) {
        //set validation to default to false
        boolean isValid = false;
         //create empty string to take in input information
        String s = "";
        //while input is invalid
        while (isValid == false) {
            System.out.print(prompt);
            // read line, if input matches "c", isValid is now true
            if (sc.hasNext("c")) {
                s = sc.nextLine();
                isValid = true;
            } else if (sc.hasNext("e")) {
                // read line, if input matches "e", isValid is now true
                s = sc.nextLine();
                isValid = true;
            } else {
                // read line, if input is not "c" or "e" display error message
                s = sc.nextLine();
                isValid = false;
                System.out.println("Error! Entry must be 'c' or 'e'. Try again.");
            }
        }
        //return the value of s
        return s;
    }
    
    public static String getStringInput(Scanner sc, String prompt) {
        //set validation to default to false
        boolean isValid = false;
        //create empty string to take in input information
        String s = "";
        
        //while input is invalid
        while (isValid == false) {
            System.out.print(prompt);
            if (sc.hasNext()) {
                s = sc.nextLine();
                isValid = true;
            } else {
                // If not a screen, display error
                System.out.println("Error! Invalid string input. Try again.");
            }
        }
        //return the value of s
        return s;
    }
}
