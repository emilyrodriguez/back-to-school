package personmanagerapp;

public class Person {
    // declare first and last name variable/fields
    private String first;
    private String last;
    
    //declare first and last name variables
    public Person(String first, String last){
       this.first = first;
       this.last = last;
    }
    
    //set value for first variable
    public void setFirstName(String first){
        this.first = first;
    }
    
    //get value for first variable
    public String getFirstName(){
        return first;
    }
    
    //set value for last variable
    public void setLastName(String last){
        this.last = last;
    }
    
    //get value for first variable
    public String getLastName(){
        return last;
    }

    //override toString() method to get person's first and last name in correct format
    @Override
    public String toString() {
        return "Name: " + this.first + " " + this.last;
    }
}
