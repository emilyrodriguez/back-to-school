package personmanagerapp;

public class Employee extends Person{
    //declare SSN variable/field
    private String SSN;
    
    //call superclass, set arguments to get first and last values, set number to blank
    public Employee(String first, String last, String SSN) {
        super(first, last);
        this.SSN = SSN;
    }

    //set value of SSN
    public void setSsn(String SSN) {
        this.SSN = SSN;
    }
    
    //get value of SSN
    public String getSsn() {
        return this.SSN;
    }
    
    //override toString() to get Employee information in correct format
    @Override
    public String toString() {
        return "You entered a new employee:\n" + super.toString() + "\nSSN: XXX-XX-" + this.SSN;                
    }
}
