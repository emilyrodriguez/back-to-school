/**
 * Emily Rodriguez
 * 7/7/18
 * Program pushes, peeks and pops out items using a linked list
 */

public class GenericStackApp {

    public static void main(String[] args) {
        Stack<String> s = new Stack<>();
        
        /**push items into stack*/
        s.push("Apples");
        System.out.println("Push: Apples");
        s.push("Oranges");
        System.out.println("Push: Oranges");
        s.push("Bananas");
        System.out.println("Push: Bananas");
        System.out.println("Stack contains " + s.size() + " items.\n" );
        
        /**peek at first item in stack*/
        System.out.println("Peek:" + s.peek());
        System.out.println("Stack contains " + s.size() + " items.\n");
        
        /**pop out items*/
        System.out.println("Pop: " + s.pop());
        System.out.println("Pop: " + s.pop());
        System.out.println("Pop: " + s.pop());
        System.out.println("Stack contains " + s.size() + " items." );
        
    }
    
}
