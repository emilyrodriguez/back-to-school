
public class Customer implements Comparable{

    private String email;
    private String firstName;
    private String lastName;

    public Customer(String email, String firstName, String lastName) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getLastName() {
        return lastName;
    }
    
    @Override
    //compare the email field of current customer to another customer
    public int compareTo(Object x) {
        Customer c = (Customer) x;
        
        //compare current email to different customer's email
        int result = this.getEmail().compareToIgnoreCase(c.getEmail());
        
        // if result is less than second string return negative int
        if (result < 0) {
            return -1;
        // if result is greater than second string return positive int
        } else if (result > 0) {
            return 1;
        // if result is equal to second string return 0
        } else {
            return 0;
        }
    }
}
