/**
 * Emily Rodriguez
 * 7/3/18
 * Program compares and sorts emails using interfaces and array sorting
 */
import java.util.Arrays;

public class SortedCustomersApp{

    public static void main(String[] args) {
        //create customer array with three elements
        Customer[] customer = new Customer[3];
        
        //populate the customer array with information
        customer[0] = new Customer("jane@email.com", "Jane", "Doe");
        customer[1] = new Customer("johnny@email.com", "Johnny", "Doe");
        customer[2] = new Customer("emily@email.com", "Emily", "Rodriguez");

        //sort customer array into Alpha order
        Arrays.sort(customer);
        
        //display customer info
        for(Customer c : customer) {
            System.out.println(c.getEmail() + " " + c.getFirstName() + " " + c.getLastName());
        }
    }
}
