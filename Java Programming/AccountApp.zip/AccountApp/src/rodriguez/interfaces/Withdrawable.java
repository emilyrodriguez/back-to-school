package rodriguez.interfaces;

/**
 * The <code>Withdrawable</code> interface is used to work with the checking and 
 * savings accounts to withdraw money from their balances
*/
public interface Withdrawable {
    /**
     * withdraws input amount
     * @param amount A <code>Double</code> value money to be withdrawn
     */
    void withdraw(double amount);
    
}
