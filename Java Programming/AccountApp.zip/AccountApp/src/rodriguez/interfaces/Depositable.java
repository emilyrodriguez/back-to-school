package rodriguez.interfaces;

/**
 * The <code>Balanceable</code> interface is used to work with the checking and 
 * savings accounts to deposit money to their balances
*/
public interface Depositable {
    /**
     * deposits input amount
     * @param amount A <code>Double</code> value money to be deposited
     */
    public void deposit(double amount);
}
