package rodriguez.interfaces;

/**
 * The <code>Balanceable</code> interface is used to work with the checking and 
 * savings accounts to get and set their balances
*/
public interface Balanceable {
    /**
     * sets account balance
     * @param amount A <code>Double</code> value of account balance
     */
    public void setBalance(double amount);
    
    /**
     * gets account balance
     * @param amount A <code>Double</code> value of account balance
     */
    public double getBalance();
}
