package rodriguez.app;


import rodriguez.interfaces.Depositable;
import rodriguez.interfaces.Withdrawable;

/**
 * The <code>AccountBalanceApp</code> class uses account objects to process and 
 * display deposits and withdrawals.
*/
public class AccountBalanceApp {
    
    /**
     * Deposits money to specified account
     * @param account An <code>object</code> that's either the savings or checking account
     * @param amount A <code>Double</code> value of money being deposited
     */
    public static void deposit(Depositable account, double amount) {
        account.deposit(amount);
    }
    
    /**
     * Withdraws money from specified account
     * @param account An <code>object</code> that's either the savings or checking account
     * @param amount A <code>Double</code> value of money being withdrawn
     */
    public static void withdraw(Withdrawable account, double amount) {
        account.withdraw(amount);
    }
}
