package rodriguez.account;

import rodriguez.account.Account;
import java.text.NumberFormat;

/**
 * The <code>SavingsAccount</code> class inherits Account class and assesses monthly interest to savings account
*/
public class SavingsAccount extends Account {
    private double monthlyInterest = 12;
    
    /**
     * Calls account superclass to get balance
     * @param balance A <code>Double</code> value of the account's balance
     */  
    
    public SavingsAccount(double balance) {
        super(balance);
    }
    
    /**
     * sets monthly interest balance
     * @param monthlyInterest A <code>Double</code> value of the $12 monthly interest
     */    
    public void setMonthlyInterest(double monthlyInterest) {
        this.monthlyInterest = monthlyInterest;
    }
    
    /**
     * gets monthly interest balance
     * @return monthlyInterest A <code>Double</code> value of the $12 monthly interest
     */ 
    public double getMonthlyInterest() {
        return monthlyInterest;
    }
    
    /**
     * gives monthly interest balance to savings account
 returns value of savings account after adding interest balance
     */
    public void giveMonthlyInterest() {
        setBalance(monthlyInterest + getBalance());
    }
    
    /**
     * Formats monthlyInterest to $x.xx
     * @return formatted monthly interest
     */
    public String getFormattedMonthlyInterest() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(this.getMonthlyInterest());
    }
    
}
