package rodriguez.account;

/**
 * The <code>CheckingAccount</code> class inherits Account class and assesses monthly fee to checking account
*/
import rodriguez.account.Account;
import java.text.NumberFormat;

public class CheckingAccount extends Account {
    private double monthlyFee = 1.0;
    
    /**
     * Calls account superclass to get balance
     * @param balance A <code>Double</code> value of the account's balance
     */ 
    
    public CheckingAccount(double balance) {
        super(balance);
    }

    /**
     * sets monthly fee
     * @param monthlyFee A <code>Double</code> value of the $1 monthly checking fee
     */
    public void setMonthlyFee(double monthlyFee) {
        this.monthlyFee = monthlyFee;
    }
    
    /**
     * gets monthly fee
     * @return monthlyFee A <code>Double</code> value of the $1 monthly checking fee
     */
    public double getMonthlyFee() {
        return monthlyFee;
    }
    
    /**
     * assess monthly fee to checking account
     * @return account balance minus monthly fee
     */
    public void substractMonthlyFee() {
        setBalance(getBalance() - monthlyFee);
    }
    
    /**
     * Formats monthlyFee to $x.xx
     * @return formatted monthly fee
     */
    public String getFormattedMonthlyFee() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(this.getMonthlyFee());
    }
}
   