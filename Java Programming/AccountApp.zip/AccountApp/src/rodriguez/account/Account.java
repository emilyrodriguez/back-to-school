package rodriguez.account;

import rodriguez.interfaces.Depositable;
import rodriguez.interfaces.Withdrawable;
import rodriguez.interfaces.Balanceable;
import java.text.NumberFormat;

/**
 * The <code>Account</code> class implements Balanceable, Depositable and Withdrawable interfaces
 * @author Emily Rodriguez
*/

public class Account implements Balanceable, Depositable, Withdrawable {
    private double balance;
    
    /**
     * Sets balance to accounts
     * @param balance A <code>Double</code> value of the account's balance
     */ 
    public Account(double balance) {
    	setBalance(balance);
    }
    
    /**
     * Sets the account's balance
     * @param amount A <code>Double</code> value of account
     */
    @Override
    public void setBalance(double amount) {
        this.balance = amount;
    }
    
    /**
     * Gets the account's balance
     * @return A <code>Double</code> of the account's total value
     */
    @Override
    public double getBalance() {
        return this.balance;
    }
 
    /**
     * Withdraws balance from account
     * @param amount A <code>Double</code> value of account
     */
    @Override
    public void withdraw(double amount) {
        this.balance -= amount;
    }
 
    /**
     * Deposits balance to account
     * @param amount A <code>Double</code> value of account
     */
    @Override
    public void deposit(double amount) {
        this.balance += amount;
    }
    
    /**
     * Takes account balance and puts it in dollar format $x.xx
     * @return A <code>Double</code> of the account's total value
     */
    public String getFormattedBalance() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(getBalance());
    }
}
