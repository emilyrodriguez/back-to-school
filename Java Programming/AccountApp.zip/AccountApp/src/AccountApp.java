import rodriguez.app.AccountBalanceApp;
import rodriguez.account.SavingsAccount;
import rodriguez.account.Account;
import rodriguez.account.CheckingAccount;
import rodriguez.presentation.Console;
import java.util.Scanner;

/**
 * @author Emily Rodriguez
 * 6/27/18
 * Program that calculates and displays the starting and ending monthly balances
 * for a checking and savings account.
 * The <code>AccountApp</code> class holds main programming logic
*/
public class AccountApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**  display a welcome message */
        System.out.println("Welcome to the Account Application");
        System.out.println();
        
        /** create Checking object and set initial value */
        CheckingAccount checkingAccount = new CheckingAccount(1000);
              
        /** create savings object and set initial value */
        SavingsAccount savingsAccount = new SavingsAccount(1000);

        /** Print out starting balances to the console in format $x.xx  */
        System.out.println("Starting Balances");
        System.out.println("Checking: " + checkingAccount.getFormattedBalance());
        System.out.println("Savings: " + savingsAccount.getFormattedBalance());
        
        System.out.println("Enter the transactions for the month");
        
        /** Default to y so program runs when loaded */
        Scanner sc = new Scanner(System.in);
        String choice = "y";
        
        /** Controls program looping as long as user chooses to continue */
        while (choice.equalsIgnoreCase("y")) {
            /** Asks user for transaction type and account type  */
           String actionType = Console.getStringAction(sc, "Withdrawal or deposit? (w/d): ");
           String accountType = Console.getStringAccntType(sc, "Checking or savings? (c/s): ");

           /** validates transaction and account type input is correct and that user cannot overdraw accounts */
           if(actionType.equalsIgnoreCase("w")) {
                if(accountType.equalsIgnoreCase("c")) {
                   double amount = Console.getInt(sc, "Amount? ");
                    if(amount > checkingAccount.getBalance()) {
                       System.out.println("Error! Amount exceeds balance in checking account.");
                    } else {
                       AccountBalanceApp.withdraw(checkingAccount, amount);
                    }
                   
                } else if (accountType.equalsIgnoreCase("s")) {
                   double amount = Console.getInt(sc, "Amount? ");
                    if(amount > savingsAccount.getBalance()) {
                       System.out.println("Error! Amount exceeds balance in savings account.");
                    } else {
                       /** performs account withdraw */
                        AccountBalanceApp.withdraw(savingsAccount, amount);
                    }
                }  
           /** validates transaction and account type input is correct and that user cannot deposit negative amounts  */
           } else if(actionType.equalsIgnoreCase("d")) {
                if(accountType.equalsIgnoreCase("c")) {
                   double amount = Console.getInt(sc, "Amount? ");
                    if(amount < 0) {
                       System.out.println("Error! Cannot deposit negative amount.");
                    } else {
                        /** performs account deposit  */
                       AccountBalanceApp.deposit(checkingAccount, amount);
                    }
                   
                } else if (accountType.equalsIgnoreCase("s")) {
                   double amount = Console.getInt(sc, "Amount? ");
                    if(amount < 0) {
                       System.out.println("Error! Cannot deposit negative amount.");
                    } else {
                        /** performs account deposit  */
                       AccountBalanceApp.deposit(savingsAccount, amount);
                    }
                }
           }
           /** asks user if they want to continue account actions  */
           choice = Console.getStringContinue(sc, "Continue? (y/n): ");    
        }
        
        /** applies monthly fee to checking account */
        checkingAccount.substractMonthlyFee();
        /** applies interest to savings account */
        savingsAccount.giveMonthlyInterest();
        
        /** displays fee, interest and final balance in format $x.xx */
        System.out.println("Monthly Payments and Fees:");
        System.out.println("Monthly Fee: " + checkingAccount.getFormattedMonthlyFee());
        System.out.println("Monthly Interest: " + savingsAccount.getFormattedMonthlyInterest());
        System.out.println();
        System.out.println("Final Balances:");
        System.out.println("Checking: " + checkingAccount.getFormattedBalance());
        System.out.println("Savings: " + savingsAccount.getFormattedBalance());
    }
}
