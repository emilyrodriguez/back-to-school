/**
 * @author Emily Rodriguez
 * 7/24/18
 * Program gets start and end dates for an appointment and calculates the total amount for the stay.
 */
package AppointmentCalculator;

import java.time.LocalDate;
import java.util.Scanner;

/**
  *  The <code>AppointmentCalculator</code> class holds main programming logic
  */
public class AppointmentCalculator {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {   
    System.out.println("Appointment Calculator");
    
    /**Creates new appointment instance*/
    Appointment appointment = new Appointment();
    LocalDate start;
    LocalDate end;
        
        /** Default to y so program runs when loaded */
        Scanner sc = new Scanner(System.in);
        String choice = "y";

        /**Keeps program looping until user ends it*/
        while (choice.equalsIgnoreCase("y")) {   
            /**Asks user for input, validates that input is an integer and is valid for the month/date*/
            int startMonth = Console.getInt(sc, "Enter the start month (1-12): ");
            if(startMonth < 0 || startMonth > 12) {
                System.out.println("Error, month number must be between 1 (Jan.) and 12 (Dec.)");
            } else {
                int startDay = Console.getInt(sc, "Enter the start day (1-31): ");
                if(startDay < 0 || startDay > 31) {
                    System.out.println("Error, day of the month must between the 1st and the 31st");
                } 
                int startYear = Console.getInt(sc, "Enter the start year: ");
                
                /**Formats any single digit month/day into two digits and puts it in YYYY-MM-DD*/
                start = LocalDate.of(startYear, startMonth, startDay);
                
                /**Sends information to the setStartDate() method*/
                appointment.setStartDate(start);                
            }
            
            /**Asks user for input, validates that input is an integer and is valid for the month/date*/
            System.out.println();
            int endMonth = Console.getInt(sc, "Enter the end month (1-12): ");
            if(endMonth < 0 || endMonth > 12) {
                System.out.println("Error, month number must be between 1 (Jan.) and 12 (Dec.)");
            } else {
                int endDay = Console.getInt(sc, "Enter the end day (1-31): ");
                if(endDay < 0 || endDay > 31) {
                    System.out.println("Error, day of the month must between the 1st and the 31st");
                } 
                int endYear = Console.getInt(sc, "Enter the end year: ");
                
                /**Formats any single digit month/day into two digits and puts it in YYYY-MM-DD*/
                end = LocalDate.of(endYear, endMonth, endDay);
                
                /**Sends information to the setEndDate() method*/
                appointment.setEndDate(end);
            }
            
            /**Outputs data in correct format*/
            
            System.out.println();
            System.out.println("Start Date: " + appointment.getStartDateFormatted());
            System.out.println("End Date: " + appointment.getEndDateFormatted());
            System.out.println("Price: " + appointment.getPricePerDaysFormatted() + " per day");
            System.out.println("Total price: " + appointment.getTotalPriceFormatted() +
                    " for " + appointment.getNumberOfDays() + " days");
            System.out.println();
            
            /**Asks user if they want to continue*/
            choice = Console.getStringContinue(sc, "Continue? (y/n): "); 
        }
        System.out.println("Bye!");
    }
}
