package AppointmentCalculator;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoUnit;

/**
 * @author Emily Rodriguez
 * The <code>Appointment</code> class contains the appointment's start and end date, it's price per day,
 * it's total cost and formatting methods
*/
public class Appointment{
    private static final double DAILY_RATE = 145.00;
    private static long totalDays;
    private static double totalPrice;
    private LocalDate startDate;
    private LocalDate endDate;
    
    /**
     * Gets the appointment's start date
     * @return A <code>LocalDate</code> object of the appointment's start date
     */
    public LocalDate getStartDate(){
        return startDate;
    }

    /**
     * Gets the appointment's formatted start date
     * @return A formatted <code>LocalDate</code> object of the appointment's start date
     */
    public String getStartDateFormatted(){
        DateTimeFormatter dtf = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
        return dtf.format(startDate);
    }

    /**
     * Sets the appointment's start date
     * @param startDate A <code>LocalDate</code> object containing appointment's start date
     */
    public void setStartDate(LocalDate startDate){
        this.startDate = startDate;
    }
    
    /**
     * Gets the appointment's end date
     * @return A <code>LocalDate</code> object of the appointment's end date
     */
    public LocalDate getEndDate(){
        return endDate;
    }
    
    /**
     * Gets the appointment's formatted end date
     * @return A formatted <code>LocalDate</code> object of the appointment's end date
     */
    public String getEndDateFormatted(){
        DateTimeFormatter dtf = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
        return dtf.format(endDate);
    }

    /**
     * Sets the appointment's end date
     * @param endDate A <code>LocalDate</code> object containing appointment's start date
     */
    public void setEndDate(LocalDate endDate){
        this.endDate = endDate;
    }

    /**
     * Gets the number of days appointment lasted by subtracting startDate and endDate
     * @return A <code>Long</code> containing the number of days the appointment lasted
     */
    public long getNumberOfDays(){
        totalDays = ChronoUnit.DAYS.between(startDate, endDate);
        return totalDays;
    }
    
    /**
     * Gets the formatted price per day
     * @return A formatted <code>Double</code> of the appointment's cost per day
     */
    public String getPricePerDaysFormatted(){
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(DAILY_RATE);
    }

    /**
     * Gets the total cost of the appointment by multiplying totalDays by the DAILY_RATE
     * @return A <code>Double</code> of the appointment's total cost
     */
    public double getTotalPrice(){
        totalPrice = getNumberOfDays() * DAILY_RATE;
        return totalPrice;
    }

    /**
     * Gets the formatted total price
     * @return A formatted <code>Double</code> of the appointment's total cost
     */
    public String getTotalPriceFormatted(){
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(getTotalPrice());
    }
}
