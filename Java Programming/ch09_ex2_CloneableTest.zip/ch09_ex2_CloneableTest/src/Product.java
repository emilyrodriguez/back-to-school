import java.text.NumberFormat;
//Create Product class and implement Cloneable interface
public class Product implements Cloneable {
    //declaring variables/fields
    private String code;
    private String description;
    private double price;

    //setting Product variable/field values to empty string and zero
    public Product() {
        code = "";
        description = "";
        price = 0;
    }

    //setting value of Product variables to the value of one particular product selected
    public Product(String code, String description, double price) {
        this.code = code;
        this.description = description;
        this.price = price;
    }

    //set the value for code variable/field
    public void setCode(String code) {
        this.code = code;
    }
    //get the value for code variable/field
    public String getCode() {
        return code;
    }
    //set the value for description variable/field
    public void setDescription(String description) {
        this.description = description;
    }
    //get the value for description variable/field
    public String getDescription() {
        return description;
    }
    //set the value for price variable/field
    public void setPrice(double price) {
        this.price = price;
    }
    //set the value for price variable/field
    public double getPrice() {
        return price;
    }
    //format price variable/field output to standard $0.00 and return new price variable
    public String getFormattedPrice() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(price);
    }

    //overrides toString() to return desired formatted output
    @Override
    public String toString() {
        return "Code:        " + code + "\n" +
               "Description: " + description + "\n" +
               "Price:       " + this.getFormattedPrice() + "\n";
    }    
    //Throws exception from Catch/Throw exception of product clone
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
