import java.text.NumberFormat;
//Create Product class and implement Cloneable interface
public class LineItem implements Cloneable {
    //declare LineItem variables/fields
    private Product product;
    private int quantity;
    private double total;
   //creates new product object and sets quantity and total to zero
    public LineItem() {
        this.product = new Product();
        this.quantity = 0;
        this.total = 0;
    }

    //sets product and quantity to equal the totals for specific product object
    public LineItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }
    //sets product value to product object's name
    public void setProduct(Product product) {
        this.product = product;
    }
    //gets product value to product object's name
    public Product getProduct() {
        return product;
    }
    //sets product quantity to the quantity of product object
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    //gets product quantity
    public int getQuantity() {
        return quantity;
    }

    //calls getTotal() method to calculate total value
    public double getTotal() {
        this.calculateTotal();
        return total;
    }
    //gives total variable/field value by multiplying product's quantity and price
    private void calculateTotal() {
        total = quantity * product.getPrice();
    }
    //formats dollar amount to $0.00
    public String getFormattedTotal() {
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        return currency.format(this.getTotal());
    }

    //overrides toString() to format all variable/field output to console
    @Override
    public String toString() {
        return
            "Code: " + product.getCode() + "\n" +
            "Description: " + product.getDescription() + "\n" +
            "Price: " + product.getFormattedPrice() + "\n" +
            "Quantity: " + quantity + "\n" +
            "Total: " + this.getFormattedTotal() + "\n";
    }    

    /*outputs original object's info and clone object's info to see the 
        changes were applied to only the second lineItem object*/
    @Override
    public Object clone() throws CloneNotSupportedException {
        LineItem li = (LineItem) super.clone();
        Product p = (Product) product.clone();
        li.setProduct(p);
        return li;
    }
}
