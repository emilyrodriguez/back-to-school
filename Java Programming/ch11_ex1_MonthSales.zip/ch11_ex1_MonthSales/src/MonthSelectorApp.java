/**
 * Emily Rodriguez
 * 7/3/18
 * Program uses arrays to connect month names with the amount of sales that took place. User can input what month they want
 * the sales information for. Upon exiting the program, a total of all the year's sales is calculated.
 */
import java.text.NumberFormat;

public class MonthSelectorApp {

    public static void main(String[] args) {
        System.out.println("Monthly Sales\n");
        
        // declare monthNames and monthSales arrays
        String[] monthName = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        Double[] monthSales = {2300.87, 1763.98, 2406.45, 3002.81, 1432.52, 2190.21, 1984.62, 2010.31, 2191.75, 2218.82, 2561.20, 2018.07};

        // get currency formatting
        NumberFormat currency = NumberFormat.getCurrencyInstance();
        
        // get one or more months
        String choice = "y";
        while (choice.equalsIgnoreCase("y")) {
            // get the input from the user
            int monthNumber = Console.getInt("Enter month number: ");
            
            // validate input
            if (monthNumber < 1 || monthNumber > monthName.length) {
                Console.displayLine("Invalid month number. Try again.");
                continue;                
            }
            
            // get the index number for the month
            int index = monthNumber - 1;
            // and display the month name and sales            
            Console.displayLine("Sales for " + monthName[index] + ": " + currency.format(monthSales[index]) + "\n");

            // check if the user wants to continue
            choice = Console.getString("Continue? (y/n): ");
            Console.displayLine();
        }
        
        // display the total sales for the year
        double sum = 0.0;
//        for(int i = 0; i < monthSales.length; i++) {
//            sum += monthSales[i];
//        }
        for(double sales: monthSales) {
            sum += sales;
        }
        Console.displayLine("Total sales: " + currency.format(sum));
        Console.displayLine();
    }    

}
