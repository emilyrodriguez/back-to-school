package murach.presentation;

import java.util.Scanner;

/**
  * <code>Console</code> class contains methods used to get input from the 
  * program and validate it
*/
public class Console {
    /**
      * Uses prompts to take input from the <code>Scanner</code> object to get a 
      * <code>String</code> from users
      * @param sc       A <code>Scanner</code> console object
      * @param prompt   A <code>String</code> prompt for the user
      * @return         A <code>String</code> that was entered by the user
    */

    private static Scanner sc = new Scanner(System.in);
    
    public static String getString(String prompt) {
        String s = "";
        boolean isValid = false;
        while (!isValid) {
            System.out.print(prompt);
            if (sc.hasNext()) {
                s = sc.nextLine(); // read entire line
                isValid = true;
            } else {
                System.out.println("Error! Invalid string value. Try again.");
            }
        }
        return s;
    }

    /**
      * Uses a prompt to take input from the <code>Scanner</code> object to get a 
      * <code>Double</code> from the user
      * @param prompt   A <code>String</code> prompt for the user
      * @return         A <code>Double</code> that was entered by the user
    */

    public static double getDouble(String prompt) {
        double d = 0;
        boolean isValid = false;
        while (!isValid) {
            System.out.print(prompt);
            if (sc.hasNextDouble()) {
                d = sc.nextDouble();
                isValid = true;
            } else {
                sc.next();     // discard the incorrectly entered double
                System.out.println("Error! Invalid decimal value. Try again.");
            }
            sc.nextLine();  // discard any other data entered on the line
        }
        return d;
    }

     /**
      * Uses a prompt to take input from the <code>Scanner</code> object to get a 
      * <code>Double</code> from the user that's within a specified range
      * @param prompt   A <code>String</code> prompt for the user
      * @param min      A <code>Double</code> minimum value
      * @param max      A <code>Double</code> maximum value
      * @return         A <code>Double</code> that was entered by the user
    */
    
    public static double getDouble(String prompt, double min, double max) {
        double d = 0;
        boolean isValid = false;
        while (!isValid) {
            d = Console.getDouble(prompt);
            if (d <= min) {
                System.out.println(
                        "Error! Number must be greater than " + min + ".");
            } else if (d >= max) {
                System.out.println(
                        "Error! Number must be less than " + max + ".");
            } else {
                isValid = true;
            }
        }
        return d;
    }

    /**
      * Uses a prompt to take input from the <code>Scanner</code> object to get a 
      * <code>Int</code> from the user
      * @param prompt   A <code>String</code> prompt for the user
      * @return         An <code>Int</code> that was entered by the user
    */
    public static int getInt(String prompt) {
        boolean isValid = false;
        int i = 0;
        while (!isValid) {
            System.out.print(prompt);
            if (sc.hasNextInt()) {
                i = sc.nextInt();
                isValid = true;
            } else {
                sc.next();  // discard invalid data
                System.out.println("Error! Invalid integer value. Try again.");
            }
            sc.nextLine();  // discard any other data entered on the line
        }
        return i;
    }
    /**
      * Uses a prompt to take input from the <code>Scanner</code> object to get a 
      * <code>Int</code> from the user
      * @param prompt   A <code>String</code> prompt for the user
      * @param min      An <code>Int</code> minimum value
      * @param max      An <code>Int</code> maximum value
      * @return         An <code>Int</code> that was entered by the user within 
      * a specified range
    */

    public static int getInt(String prompt, int min, int max) {
        int i = 0;
        boolean isValid = false;
        while (!isValid) {
            i = Console.getInt(prompt);
            if (i <= min) {
                System.out.println(
                        "Error! Number must be greater than " + min + ".");
            } else if (i >= max) {
                System.out.println(
                        "Error! Number must be less than " + max + ".");
            } else {
                isValid = true;
            }
        }
        return i;
    }
}