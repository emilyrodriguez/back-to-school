/**
 * @author Emily Rodriguez
 * 7/24/18
 * Program creates a series of emails based on the number of users in the array
 */
package emailapp;

import java.util.ArrayList;
import java.util.List;

/**
  *  The <code>EmailApp</code> class holds main programming logic
  */
public class EmailApp {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /**Creates an ArrayList of users*/
        List<String> userInfo = new ArrayList<>();        
        userInfo.add("   james   ,butler,jbutler@gmail.com");
        userInfo.add("Josephine,Darakjy,Josephine_Darakjy@darakjy.org");
        userInfo.add("ART,VENERE,ART@VENERE.ORG");

        System.out.println("Emails");
        /**Iterates through userInfo to create individual users*/
        for (String user : userInfo) {
            String firstName;
            String email;
            
            /**splits userInfo into single user arrays based on usersInfo's length*/
            String[] userData = user.trim().split(",");
            
            /**splits individual user array into variables first_name and email*/
            firstName = userData[0];
            email = userData[2];
           
            /**Outputs email in desired format*/
            System.out.println("================================================================");
            System.out.println();
            
            /**Fills out template with formatted user information*/
            String template =
                "To:      "+ email.toLowerCase() + "\n" +
                "From:    noreply@deals.com\n" +
                "Subject: Deals!\n\n" +
                "Hi "+ formatName(firstName) + ",\n\n" +
                "We've got some great deals for you. Check our website!";
            
            System.out.println(template);
            System.out.println();
            System.out.println("================================================================");
        }
    }
    
    /**
     * 
     * @param string A <code>String</code> containing user's first name
     * @return A <code>String</code> containing user's first name in title case and trimmed
     */
    public static String formatName(String string){
        String result = "";
        String formattedName;
        
        /**Iterates through characters of firstName and capitalizes the first letter*/
        for (int i = 0; i < string.length(); i++){
            String nextLetter = string.substring(i, i + 1);
            if (i == 0){
                result += nextLetter.toUpperCase();
            } else {
                result += nextLetter.toLowerCase();
            }
        }
        
       formattedName = result.trim();
       return formattedName;
    }

}
