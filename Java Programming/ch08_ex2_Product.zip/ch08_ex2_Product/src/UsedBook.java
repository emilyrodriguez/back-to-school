/**
 *
 * @author emilyrodriguez
 */

public class UsedBook extends Book{
    //Overriding getDisplayText() of Book class, then return empty string.
    @Override
    public String getDisplayText() {
        return "";
    }
}
