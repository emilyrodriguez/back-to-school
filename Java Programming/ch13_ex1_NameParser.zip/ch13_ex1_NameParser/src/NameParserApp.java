/**
 * Emily Rodriguez
 * 7/15/18
 * Code takes in a name and separates it by first name, last name and middle name if applicable.
 */

package src;
import java.util.Scanner;

public class NameParserApp {

    public static void main(String[] args) {
        
        /**Create scanner and ask for name input*/
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a name: ");
        String name = sc.nextLine();
        System.out.println();
        
        /**Trim any extra spaces from name input*/
        name = name.trim();
        
        /**Make index1 equal to first word entered*/
        int index1 = name.indexOf(" ");
        
        /**If index1 empty, display error*/
        if(index1 == -1) {
            System.out.println("Invalid name input entry.");
        } else {
            /**Make index2 equal to the second word entered*/
            int index2 = name.indexOf(" ", index1 + 1);
           
            if(index2 == -1) {
                /**Set index1 to firstName and index2 to lastName*/
                String firstName = name.substring(0, index1);
                String lastName = name.substring(index1 + 1);
                
                /**Print firstName and lastName*/
                System.out.println("First name: " + firstName);
                System.out.println("Last name: " + lastName);
            } else {
                /**Make index3 equal to the third word in the string*/
                int index3 = name.indexOf(" ", index2 + 1);
                
                if(index3 == -1) {
                    /**Set index1 to firstName, index2 to middleName and index3 to lastName*/
                    String firstName = name.substring(0, index1);
                    String middleName = name.substring(index1 + 1, index2);
                    String lastName = name.substring(index2 + 1);
                    
                    /**Print firstName, middleName and lastName*/
                    System.out.println("First name: " + firstName);
                    System.out.println("Middle name: " + middleName);
                    System.out.println("Last name: " + lastName);
                } else {
                    /**If user enters more than three words, display error*/
                    System.out.println("Invalid name input entry.");
                }
            }
        }
    }
}
