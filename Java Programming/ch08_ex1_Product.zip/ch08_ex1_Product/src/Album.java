/**
 *
 * @author emilyrodriguez
 * Creating new Album class that extends Product superclass
 */
public class Album extends Product {
    // declare artist variable
    private String artist;
    
    //call parent constructor, set artist to blank, add 1 to count as used
    public Album() {
        super();
        artist = "";
        count++;
    }
    
    //set value for artist variable for paricular album
    public void setArtist(String artist){
        this.artist = artist;
    }
    
    //get value for artist variable for paricular album
    public String getArtist() {
        return artist;
    }
    
    //Append name of artist to the end of string
    @Override
    public String toString() {
        return super.toString() + " (" + getArtist() + ")";
    }
    
}
